var dataList = [
    {
        name:"ABOUT ME",
        desc:"I am currently a Year 2 Student in Nanyang Polytechnic studying Game Development & Technology.",
        imgName: "jordanEars.png",
        buttonLink: "page2.html",
        id: "aboutButton",
        latest: "hob"
    },
    {
        name:"PORTFOLIO",
        desc:"Over the years, I've worked on a couple of projects that I'm extremely proud of.",
        imgName: "jordanEarsPurple.png",
        buttonLink: "page2.html",
        id: "portfolioButton",
        latest: "port"
    },
    {
        name:"CONTACT ME",
        desc:"Be it whether you want to collaborate or for business enquires, feel free to contact me.",
        imgName: "jordanBunny.png",
        buttonLink: "",
        id: "contactButton"
    }
];
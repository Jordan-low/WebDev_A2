var dataList2 = [
    {
        page:"hobbies",
        name:"BASKETBALL",
        desc:"I love playing basketball during my free time ever since I was introduced to it in secondary school.",
        imgName: "jordanBball.png"
    },
    {
        page:"hobbies",
        name:"VIDEO GAMES",
        desc:"I love playing video games with my friends to help relieve my stress, and to get my mind off things. My current main game is Apex Legends.",
        imgName: "jordanApex.gif"
    },
    {
        page:"hobbies",
        name:"CODING",
        desc:"I enjoy working on small coding projects during my free time to brush up my coding skills. Honestly, I kinda enjoy coding and I really like that sense of accomplishment when you've finally managed to solve the problem.",
        imgName: "jordanCoding.gif"
    },
    {
        page:"education",
        name:"HOUGANG PRIMARY",
        desc:"PSLE Score: 182 (English: B, Chinese: C, Math: B, Science: C)",
        imgName: "hgps.png"
    },
    {
        page:"education",
        name:"BOWEN SECONDARY",
        desc:"N Level EMB3: 11 (English: B3, Maths: A2, Science(Phys/Chem): A2, Humanities(SS/Hist): A2, F&N: A2, Chinese: B4)",
        imgName: "bowen.png"
    },
    {
        page:"education",
        name:"NANYANG POLYTECHNIC",
        desc:"Year 1 GPA: 3.39 (Sem 1: 3.0, Sem 2: 3.72)",
        imgName: "nyp.png"
    },
    {
        page:"portfolio",
        name:"MyPass",
        desc:"This is my Year 1 Intro-to-coding Assignment 2. MyPass is a password manager tool that allows you to store all your emails/usernames and passwords. This can be very convenient as you do not need to remember your email and password for each account that you created. This means that you can have different passwords for different accounts which is ideal as you do not want to be using the same password for every account that you own.",
        imgName: "passw.png"
    },
    {
        page:"portfolio",
        name:"SP1",
        desc:"This is my group's Year 1 SP1 Game. In 2020, the world went through many crises, one of which was hornets mutating to become man-eating creatures. This caused the world to meet its end. Now it’s up to our hero, Robert, to somehow restore the world back to its original peaceful state.",
        imgName: "sp1.png"
    },
    {
        page:"portfolio",
        name:"SP2",
        desc:"This is my group's Year 1 SP2 Game. You travel back in time to 2021 from 2051 so that you can seek revenge on the person (Bimster) who destroyed your life. While you are in 2021, you decide to explore the city so that you can find his location.",
        imgName: "sp2.png"
    }
];